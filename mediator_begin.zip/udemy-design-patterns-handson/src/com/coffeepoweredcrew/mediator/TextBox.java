package com.coffeepoweredcrew.mediator;

import javafx.scene.control.TextField;

public class TextBox extends TextField{
	
	public TextBox() {
		this.setText("Textbox");
	}
	
}
