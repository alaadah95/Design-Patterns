package com.coffeepoweredcrew.mediator;

import java.util.ArrayList;
import java.util.List;

//Mediator
public class UIMediator {

}
